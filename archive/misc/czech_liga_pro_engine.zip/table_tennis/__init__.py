"""Table tennis package initialization."""
