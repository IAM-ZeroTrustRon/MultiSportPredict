#!/usr/bin/env python3
"""
NCAAF Daily Data Ingest
Pulls today's games, odds, consensus, and team stats
Uses ESPN API + CFBData API (both free, no auth)
Stores to JSON and SQLite for model pipeline
"""

import requests
import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
import logging

# Config
DATA_DIR = Path("data/ncaaf")
DB_FILE = DATA_DIR / "ncaaf.db"
LOG_FILE = DATA_DIR / "ingest.log"
DATA_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# APIs
ESPN_BASE = "https://site.api.espn.com/apis/site/v2/sports/football/college-football"
CFBDATA_BASE = "https://api.collegefootballdata.com"

def get_today_games():
    """Fetch today's NCAAF games from ESPN"""
    try:
        url = f"{ESPN_BASE}/scoreboard"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        games = data.get('events', [])
        logger.info(f"Fetched {len(games)} games from ESPN")
        return games
    except Exception as e:
        logger.error(f"Failed to fetch games: {e}")
        return []

def get_cfbdata_games():
    """Fetch today's games from CFBData API"""
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        # CFBData is free but might have rate limits; no auth required
        url = f"{CFBDATA_BASE}/games?year={datetime.now().year}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        games = resp.json()
        
        # Filter to today
        today_games = [g for g in games if g.get('start_date', '')[:10] == today]
        logger.info(f"Fetched {len(today_games)} games from CFBData for {today}")
        return today_games
    except Exception as e:
        logger.warning(f"CFBData API error: {e}")
        return []

def get_odds_lines(game_id):
    """Fetch odds/lines from ESPN"""
    try:
        url = f"{ESPN_BASE}/events/{game_id}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        odds = {}
        event = data.get('events', [{}])[0]
        
        if 'links' in event:
            for link in event['links']:
                if 'odds' in link.get('text', '').lower():
                    odds['link'] = link.get('href')
        
        # Extract betting lines from articles if available
        articles = data.get('articles', [])
        for article in articles:
            if 'odd' in article.get('description', '').lower():
                odds['article'] = article.get('links', [{}])[0].get('href')
        
        return odds
    except Exception as e:
        logger.warning(f"Could not fetch odds for game {game_id}: {e}")
        return {}

def get_team_stats(team_id):
    """Fetch team stats from CFBData"""
    try:
        year = datetime.now().year
        url = f"{CFBDATA_BASE}/teams/stats?year={year}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        teams = resp.json()
        
        team = next((t for t in teams if t.get('team_id') == team_id), None)
        return team or {}
    except Exception as e:
        logger.error(f"Failed to fetch team stats: {e}")
        return {}

def get_ratings(team_id):
    """Fetch SP+, FEI ratings from CFBData"""
    try:
        year = datetime.now().year
        url = f"{CFBDATA_BASE}/ratings?year={year}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        ratings = resp.json()
        
        team_ratings = next((r for r in ratings if r.get('team_id') == team_id), None)
        return team_ratings or {}
    except Exception as e:
        logger.warning(f"Failed to fetch ratings: {e}")
        return {}

def get_consensus_picks(matchup_name):
    """Scrape consensus from betting sites (ESPN links)"""
    # Note: ESPN articles often contain consensus/expert picks
    # This would require parsing ESPN articles or connecting to a consensus API
    logger.info(f"Consensus picks for {matchup_name} requires manual ESPN article scrape")
    return {}

def init_db():
    """Initialize SQLite database schema"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    # Games table
    c.execute('''
    CREATE TABLE IF NOT EXISTS games (
        game_id TEXT PRIMARY KEY,
        date TEXT,
        week INTEGER,
        away_team TEXT,
        home_team TEXT,
        away_id INTEGER,
        home_id INTEGER,
        status TEXT,
        start_time TEXT,
        venue TEXT,
        away_score INTEGER,
        home_score INTEGER,
        away_rank INTEGER,
        home_rank INTEGER,
        ingested_at TEXT
    )
    ''')
    
    # Betting lines table
    c.execute('''
    CREATE TABLE IF NOT EXISTS betting_lines (
        game_id TEXT,
        date TEXT,
        spread REAL,
        spread_direction TEXT,
        over_under REAL,
        moneyline_away INTEGER,
        moneyline_home INTEGER,
        public_pct_away REAL,
        public_pct_home REAL,
        sharp_action TEXT,
        ingested_at TEXT,
        PRIMARY KEY (game_id, date)
    )
    ''')
    
    # Team season stats
    c.execute('''
    CREATE TABLE IF NOT EXISTS team_season_stats (
        team_id INTEGER,
        team_name TEXT,
        date TEXT,
        wins INTEGER,
        losses INTEGER,
        points_for REAL,
        points_against REAL,
        total_yards INTEGER,
        pass_yards INTEGER,
        rush_yards INTEGER,
        turnovers INTEGER,
        ingested_at TEXT,
        PRIMARY KEY (team_id, date)
    )
    ''')
    
    # Ratings (SP+, FEI, etc.)
    c.execute('''
    CREATE TABLE IF NOT EXISTS team_ratings (
        team_id INTEGER,
        team_name TEXT,
        date TEXT,
        sp_plus REAL,
        sp_plus_rank INTEGER,
        fei REAL,
        fei_rank INTEGER,
        elo REAL,
        bpi REAL,
        ingested_at TEXT,
        PRIMARY KEY (team_id, date)
    )
    ''')
    
    # Expert consensus picks
    c.execute('''
    CREATE TABLE IF NOT EXISTS consensus (
        game_id TEXT,
        date TEXT,
        matchup TEXT,
        spread_consensus TEXT,
        total_consensus TEXT,
        moneyline_consensus TEXT,
        percent_experts_away REAL,
        percent_experts_home REAL,
        sharp_picks TEXT,
        ingested_at TEXT,
        PRIMARY KEY (game_id, date)
    )
    ''')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")

def store_games(games):
    """Store games in database"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    now = datetime.now().isoformat()
    
    for game in games:
        try:
            game_id = game.get('id', '')
            date = game.get('date', '').split('T')[0]
            
            # Parse competitors
            competitors = game.get('competitions', [{}])[0].get('competitors', [])
            away = competitors[0] if len(competitors) > 0 else {}
            home = competitors[1] if len(competitors) > 1 else {}
            
            away_team = away.get('team', {}).get('displayName', 'Unknown')
            home_team = home.get('team', {}).get('displayName', 'Unknown')
            away_id = away.get('team', {}).get('id', '')
            home_id = home.get('team', {}).get('id', '')
            
            away_score = int(away.get('score', 0) or 0)
            home_score = int(home.get('score', 0) or 0)
            
            status = game.get('status', {}).get('type', {}).get('state', 'Unknown')
            start_time = game.get('date', '')
            venue = game.get('competitions', [{}])[0].get('venue', {}).get('fullName', 'Unknown')
            
            # Ranks (if applicable)
            away_rank = away.get('rank', None)
            home_rank = home.get('rank', None)
            
            week = game.get('week', 0)
            
            c.execute('''
            INSERT OR REPLACE INTO games 
            (game_id, date, week, away_team, home_team, away_id, home_id, status,
             start_time, venue, away_score, home_score, away_rank, home_rank, ingested_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (game_id, date, week, away_team, home_team, away_id, home_id, status,
                  start_time, venue, away_score, home_score, away_rank, home_rank, now))
            
            logger.info(f"Stored game {game_id}: {away_team} @ {home_team}")
        except Exception as e:
            logger.error(f"Error storing game: {e}")
    
    conn.commit()
    conn.close()

def main():
    logger.info("=" * 60)
    logger.info("NCAAF Daily Ingest Started")
    logger.info("=" * 60)
    
    init_db()
    
    # Get today's games from both sources
    espn_games = get_today_games()
    cfbdata_games = get_cfbdata_games()
    
    if not espn_games and not cfbdata_games:
        logger.warning("No games found for today")
        return
    
    # Store ESPN games (has odds links)
    if espn_games:
        store_games(espn_games)
    
    # Save raw JSONs for backup
    today = datetime.now().strftime("%Y-%m-%d")
    
    if espn_games:
        json_file = DATA_DIR / f"espn_games_{today}.json"
        with open(json_file, 'w') as f:
            json.dump(espn_games, f, indent=2)
        logger.info(f"Saved ESPN JSON: {json_file}")
    
    if cfbdata_games:
        json_file = DATA_DIR / f"cfbdata_games_{today}.json"
        with open(json_file, 'w') as f:
            json.dump(cfbdata_games, f, indent=2)
        logger.info(f"Saved CFBData JSON: {json_file}")
    
    logger.info("=" * 60)
    logger.info("NCAAF Ingest Complete")
    logger.info("=" * 60)

if __name__ == "__main__":
    main()
