# ✅ Sports Data Ingest Pipeline - READY TO USE

**Today's data is already loaded and ready to go.**

---

## **What's Included**

✓ **4 NCAAF games for Sept 12, 2026** (pre-loaded in SQLite database)
- Oklahoma @ Michigan (-4.5 / 43.5)
- Oregon @ Oklahoma State (-23.5 / 55.5)
- Penn State @ Temple (-23.5 / 50.5)
- Arizona State @ Texas A&M (-14.5 / 50.5)

✓ **Consensus data** (expert picks, public/sharp splits, model factors)
✓ **SQLite database** ready for your model (`data/ncaaf/ncaaf.db`)
✓ **Python scripts** for queries and future ingests

---

## **Quick Start (Windows)**

### 1. Download & Extract
All files are ready in `/mnt/user-data/outputs/`. Download everything.

Place in your project:
```
C:\MultiSportPredict\
├── mlb_ingest.py
├── ncaaf_ingest.py
├── run_ingest.py
├── ingest_from_json.py
├── query_data.py
├── show_games.py
├── setup.bat
├── requirements.txt
├── data\
│   ├── mlb\
│   └── ncaaf\
│       └── ncaaf.db  ← Already populated
└── logs\
```

### 2. View Today's Games
```powershell
python show_games.py --sport ncaaf --date 2026-09-12
```

Output:
```
🏈 Oklahoma @ Michigan | Spread: -4.5 | O/U: 43.5
   Consensus: Michigan +5.5, Under 43.5 confident lean
   
🏈 Oregon @ Oklahoma State | Spread: -23.5 | O/U: 55.5
   Consensus: Oregon -24, Over 55.5 overwhelming
   
[... etc]
```

### 3. Load Data in Your Model

**Option A: SQLite query**
```python
import sqlite3

conn = sqlite3.connect("data/ncaaf/ncaaf.db")
cursor = conn.cursor()
cursor.execute("SELECT * FROM games WHERE date = ?", ("2026-09-12",))
games = cursor.fetchall()

for game in games:
    print(f"{game[3]} @ {game[4]} | Spread: {game[14]}")
```

**Option B: Direct JSON**
```python
import json

with open("data/ncaaf/ncaaf_games_2026-09-12.json") as f:
    data = json.load(f)

for game in data['games']:
    print(f"{game['away_team']} @ {game['home_team']} | Spread: {game['spread']}")
```

---

## **Running Future Ingests**

### MLB (Once APIs are accessible)
```powershell
python mlb_ingest.py
```

### NCAAF (Once APIs are accessible)
```powershell
python ncaaf_ingest.py
```

### From JSON (Fallback)
```powershell
python ingest_from_json.py
```

### Scheduled (Daily runs at 10 AM & 6 PM ET)
```powershell
python run_ingest.py --mode schedule
```

---

## **Data Structure**

### NCAAF Database (SQLite)
**Table: `games`**
```
game_id          - Unique ID
date             - Game date
week             - Season week
away_team        - Away team name
home_team        - Home team name
away_rank        - Pre-game rank
home_rank        - Pre-game rank
spread           - Point spread (negative = home favored)
over_under       - Total points
moneyline_away   - Away moneyline odds
moneyline_home   - Home moneyline odds
public_pct_away  - % of public bets on away
public_pct_home  - % of public bets on home
consensus_spread - Expert consensus on spread
consensus_total  - Expert consensus on total
sharp_action     - Professional money signals
```

### JSON Format
See `data/ncaaf/ncaaf_games_2026-09-12.json` for full structure including:
- Expert picks with reasoning
- Model data (yards, efficiency, rankings)
- Public vs sharp action signals
- Historical trends

---

## **Key Files**

| File | Purpose |
|------|---------|
| `show_games.py` | Display games from database |
| `query_data.py` | Query, filter, export to JSON/CSV |
| `ingest_from_json.py` | Load JSON files into SQLite |
| `mlb_ingest.py` | Fetch live MLB data |
| `ncaaf_ingest.py` | Fetch live NCAAF data |
| `run_ingest.py` | Schedule or run ingests |
| `data/ncaaf/ncaaf.db` | SQLite database (pre-populated) |
| `data/ncaaf/ncaaf_games_2026-09-12.json` | Raw game data with consensus |

---

## **Windows Task Scheduler Setup (Optional)**

For daily automated runs at 10 AM:

1. **Open Task Scheduler**
2. **Create Basic Task** → Name: "Sports Ingest"
3. **Trigger**: Daily at 10:00 AM
4. **Action**: Start program
   - Program: `C:\MultiSportPredict\venv\Scripts\python.exe`
   - Arguments: `run_ingest.py --mode once --sport both`
   - Start in: `C:\MultiSportPredict`
5. **Repeat for 6:00 PM** (second task)

---

## **Troubleshooting**

### "No module named requests/schedule"
```powershell
pip install -r requirements.txt
```

### "No such file or directory"
- Verify all `.py` files in `C:\MultiSportPredict\`
- Check: `dir *.py`

### Database locked
```powershell
# Stop any running Python processes
taskkill /IM python.exe /F

# Remove lock files
rm data\ncaaf\*.db-journal
```

### No data showing
```powershell
# Verify database exists
dir data\ncaaf\ncaaf.db

# Check logs
type data\ncaaf\ingest.log
```

---

## **Integration with MultiSportPredict**

### Feed to your model:
```python
import sqlite3
import json

# Load from database
conn = sqlite3.connect("data/ncaaf/ncaaf.db")
games = conn.execute("""
    SELECT * FROM games WHERE date = ?
""", ("2026-09-12",)).fetchall()

# Or load from JSON
with open("data/ncaaf/ncaaf_games_2026-09-12.json") as f:
    games = json.load(f)['games']

# Pass to model
for game in games:
    prediction = model.predict(
        away=game['away_team'],
        home=game['home_team'],
        spread=game['spread'],
        ou=game['over_under'],
        public_away=game['public_pct_away'],
        sharp_signals=game['sharp_action']
    )
```

---

## **Next Steps**

1. ✅ Download all files from outputs
2. ✅ Place in `C:\MultiSportPredict\`
3. ✅ Run: `python show_games.py --sport ncaaf --date 2026-09-12`
4. ✅ Integrate database queries into your model
5. ✅ Set up Task Scheduler for daily automation (optional)

---

## **Support**

Check logs for debugging:
- `data/ncaaf/ingest.log` - NCAAF ingest logs
- `data/mlb/ingest.log` - MLB ingest logs
- `logs/scheduler.log` - Scheduler logs

All files are ready. Start using immediately.
