#!/usr/bin/env python3
"""
Ingest from JSON files to SQLite (fallback when APIs fail)
Handles data already fetched and saved as JSON
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path

def init_db(db_path):
    """Initialize SQLite database"""
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    
    # Drop old table if exists
    c.execute('DROP TABLE IF EXISTS games')
    
    c.execute('''
    CREATE TABLE games (
        game_id TEXT PRIMARY KEY,
        date TEXT,
        week INTEGER,
        away_team TEXT,
        home_team TEXT,
        away_id INTEGER,
        home_id INTEGER,
        status TEXT,
        start_time TEXT,
        venue TEXT,
        away_score INTEGER,
        home_score INTEGER,
        away_rank INTEGER,
        home_rank INTEGER,
        spread REAL,
        over_under REAL,
        moneyline_away INTEGER,
        moneyline_home INTEGER,
        public_pct_away REAL,
        public_pct_home REAL,
        consensus_spread TEXT,
        consensus_total TEXT,
        sharp_action TEXT,
        ingested_at TEXT
    )
    ''')
    
    conn.commit()
    conn.close()

def load_ncaaf_json(json_file, db_path):
    """Load NCAAF JSON into database"""
    with open(json_file) as f:
        data = json.load(f)
    
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    now = datetime.now().isoformat()
    
    for game in data.get('games', []):
        c.execute('''
        INSERT OR REPLACE INTO games 
        (game_id, date, week, away_team, home_team, away_id, home_id, status,
         start_time, venue, away_score, home_score, away_rank, home_rank,
         spread, over_under, moneyline_away, moneyline_home,
         public_pct_away, public_pct_home, consensus_spread, consensus_total,
         sharp_action, ingested_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            game.get('game_id'),
            game.get('date'),
            game.get('week'),
            game.get('away_team'),
            game.get('home_team'),
            game.get('away_id'),
            game.get('home_id'),
            game.get('status'),
            game.get('start_time'),
            game.get('venue'),
            game.get('away_score', 0),
            game.get('home_score', 0),
            game.get('away_rank'),
            game.get('home_rank'),
            game.get('spread'),
            game.get('over_under'),
            game.get('moneyline_away'),
            game.get('moneyline_home'),
            game.get('public_pct_away'),
            game.get('public_pct_home'),
            game.get('consensus_spread'),
            game.get('consensus_total'),
            game.get('sharp_action'),
            now
        ))
        print(f"Loaded: {game.get('away_team')} @ {game.get('home_team')}")
    
    conn.commit()
    conn.close()
    print(f"\n✓ Ingested {len(data.get('games', []))} NCAAF games")

if __name__ == "__main__":
    # Create database
    db_path = Path("data/ncaaf/ncaaf.db")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    init_db(db_path)
    
    # Load JSON files
    json_file = Path("data/ncaaf/ncaaf_games_2026-09-12.json")
    if json_file.exists():
        load_ncaaf_json(json_file, db_path)
    else:
        print(f"JSON file not found: {json_file}")
