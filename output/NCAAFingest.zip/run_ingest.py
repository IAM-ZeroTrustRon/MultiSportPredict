#!/usr/bin/env python3
"""
Data Ingest Scheduler
Runs MLB and NCAAF ingestion on schedule
Run with: python run_ingest.py [--once | --schedule]
"""

import subprocess
import schedule
import time
import logging
import argparse
from pathlib import Path
from datetime import datetime

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_DIR / "scheduler.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def run_mlb_ingest():
    """Execute MLB ingest"""
    logger.info("Starting MLB ingest...")
    try:
        result = subprocess.run(
            ["python", "mlb_ingest.py"],
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode == 0:
            logger.info("MLB ingest completed successfully")
        else:
            logger.error(f"MLB ingest failed: {result.stderr}")
    except Exception as e:
        logger.error(f"Error running MLB ingest: {e}")

def run_ncaaf_ingest():
    """Execute NCAAF ingest"""
    logger.info("Starting NCAAF ingest...")
    try:
        result = subprocess.run(
            ["python", "ncaaf_ingest.py"],
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode == 0:
            logger.info("NCAAF ingest completed successfully")
        else:
            logger.error(f"NCAAF ingest failed: {result.stderr}")
    except Exception as e:
        logger.error(f"Error running NCAAF ingest: {e}")

def run_both():
    """Run both ingests"""
    logger.info("=" * 60)
    logger.info(f"Starting dual ingest at {datetime.now()}")
    logger.info("=" * 60)
    
    run_mlb_ingest()
    run_ncaaf_ingest()
    
    logger.info("=" * 60)
    logger.info(f"Dual ingest complete at {datetime.now()}")
    logger.info("=" * 60)

def schedule_jobs():
    """Schedule recurring ingest jobs"""
    # Run at 10 AM ET (before most games start)
    schedule.every().day.at("10:00").do(run_both)
    
    # Optional: Run again at 6 PM for evening games
    schedule.every().day.at("18:00").do(run_both)
    
    logger.info("Scheduler started. Jobs scheduled for 10:00 AM and 6:00 PM ET")
    logger.info("Press Ctrl+C to stop")
    
    try:
        while True:
            schedule.run_pending()
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("Scheduler stopped by user")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run data ingest jobs")
    parser.add_argument(
        "--mode",
        choices=["once", "schedule"],
        default="once",
        help="Run once or schedule recurring jobs"
    )
    parser.add_argument(
        "--sport",
        choices=["mlb", "ncaaf", "both"],
        default="both",
        help="Which sport to ingest"
    )
    
    args = parser.parse_args()
    
    if args.mode == "once":
        if args.sport in ["mlb", "both"]:
            run_mlb_ingest()
        if args.sport in ["ncaaf", "both"]:
            run_ncaaf_ingest()
    else:
        schedule_jobs()
