#!/usr/bin/env python3
"""
Display loaded games data
Usage: python show_games.py --sport [mlb|ncaaf] --date [YYYY-MM-DD]
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
import argparse

def show_ncaaf_games(date=None):
    """Display NCAAF games"""
    db = Path("data/ncaaf/ncaaf.db")
    if not db.exists():
        print("NCAAF database not found")
        return
    
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    if date:
        c.execute("SELECT * FROM games WHERE date = ? ORDER BY start_time", (date,))
    else:
        c.execute("SELECT * FROM games ORDER BY date DESC, start_time")
    
    games = [dict(row) for row in c.fetchall()]
    conn.close()
    
    if not games:
        print("No games found")
        return
    
    print(f"\n{'='*120}")
    print(f"NCAAF Games - {games[0]['date'] if date else 'All Dates'}")
    print(f"{'='*120}\n")
    
    for game in games:
        print(f"🏈 {game['away_team']:15} @ {game['home_team']:15} | Week {game['week']}")
        print(f"   Time: {game['start_time']} | Venue: {game['venue']}")
        print(f"   Spread: {game['spread']:+.1f} | O/U: {game['over_under']:.1f} | Moneyline: {game['moneyline_away']:+d}/{game['moneyline_home']:+d}")
        print(f"   Public: {game['public_pct_away']:.0f}% {game['away_team']} / {game['public_pct_home']:.0f}% {game['home_team']}")
        print(f"   Consensus Spread: {game['consensus_spread']}")
        print(f"   Consensus Total: {game['consensus_total']}")
        print(f"   Sharp Action: {game['sharp_action']}")
        print()

def show_mlb_games(date=None):
    """Display MLB games"""
    db = Path("data/mlb/mlb.db")
    if not db.exists():
        print("MLB database not found")
        return
    
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    if date:
        c.execute("SELECT * FROM games WHERE date = ? ORDER BY start_time", (date,))
    else:
        c.execute("SELECT * FROM games ORDER BY date DESC, start_time")
    
    games = [dict(row) for row in c.fetchall()]
    conn.close()
    
    if not games:
        print("No games found")
        return
    
    print(f"\n{'='*100}")
    print(f"MLB Games - {games[0]['date'] if date else 'All Dates'}")
    print(f"{'='*100}\n")
    
    for game in games:
        print(f"⚾ {game['away_team']:15} @ {game['home_team']:15}")
        print(f"   Time: {game['start_time']} | Venue: {game['venue']}")
        print(f"   Score: {game['away_score']}-{game['home_score']} | Inning: {game['inning']} | Status: {game['status']}")
        print()

def main():
    parser = argparse.ArgumentParser(description="Display sports data")
    parser.add_argument("--sport", choices=["mlb", "ncaaf"], default="ncaaf")
    parser.add_argument("--date", type=str, help="Date (YYYY-MM-DD)")
    
    args = parser.parse_args()
    
    if args.sport == "ncaaf":
        show_ncaaf_games(args.date)
    else:
        show_mlb_games(args.date)

if __name__ == "__main__":
    main()
