#!/usr/bin/env python3
"""
MLB Daily Data Ingest
Pulls today's games, odds, and team stats from StatsBomb/MLB-StatsAPI
Stores to JSON for model pipeline
"""

import requests
import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
import logging

# Config
DATA_DIR = Path("data/mlb")
DB_FILE = DATA_DIR / "mlb.db"
LOG_FILE = DATA_DIR / "ingest.log"
DATA_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# MLB-StatsAPI (free, no key)
STATSAPI_BASE = "https://statsapi.mlb.com/api/v1"

def get_today_games():
    """Fetch today's MLB games"""
    today = datetime.now().strftime("%Y-%m-%d")
    url = f"{STATSAPI_BASE}/schedule?sportId=1&date={today}"
    
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        games = resp.json()
        logger.info(f"Fetched {len(games)} games for {today}")
        return games
    except Exception as e:
        logger.error(f"Failed to fetch games: {e}")
        return []

def get_game_odds(game_id):
    """Fetch odds from ESPN endpoint (MLB)"""
    try:
        # ESPN odds endpoint (free, no auth)
        url = f"https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/events/{game_id}"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        odds = {}
        if 'article' in data and 'links' in data['article']:
            for link in data['article']['links']:
                if 'odds' in link.get('text', '').lower():
                    odds['link'] = link.get('href')
        
        return odds
    except Exception as e:
        logger.warning(f"Could not fetch odds for game {game_id}: {e}")
        return {}

def get_team_stats(team_id):
    """Fetch team season stats"""
    try:
        url = f"{STATSAPI_BASE}/teams/{team_id}?hydrate=record"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"Failed to fetch team {team_id} stats: {e}")
        return {}

def get_player_stats(game_id):
    """Fetch boxscore and player stats for a game"""
    try:
        url = f"{STATSAPI_BASE}/game/{game_id}/boxscore"
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"Failed to fetch boxscore {game_id}: {e}")
        return {}

def init_db():
    """Initialize SQLite database schema"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    # Games table
    c.execute('''
    CREATE TABLE IF NOT EXISTS games (
        game_id TEXT PRIMARY KEY,
        date TEXT,
        away_team TEXT,
        home_team TEXT,
        away_id INTEGER,
        home_id INTEGER,
        status TEXT,
        start_time TEXT,
        venue TEXT,
        away_score INTEGER,
        home_score INTEGER,
        inning INTEGER,
        ingested_at TEXT
    )
    ''')
    
    # Team stats table
    c.execute('''
    CREATE TABLE IF NOT EXISTS team_stats (
        team_id INTEGER,
        team_name TEXT,
        date TEXT,
        wins INTEGER,
        losses INTEGER,
        win_pct REAL,
        run_diff INTEGER,
        ingested_at TEXT,
        PRIMARY KEY (team_id, date)
    )
    ''')
    
    # Player performance (daily)
    c.execute('''
    CREATE TABLE IF NOT EXISTS player_daily (
        player_id INTEGER,
        player_name TEXT,
        team_id INTEGER,
        game_id TEXT,
        date TEXT,
        ab INTEGER,
        hits INTEGER,
        runs INTEGER,
        rbis INTEGER,
        hr INTEGER,
        avg REAL,
        obp REAL,
        slg REAL,
        ingested_at TEXT,
        PRIMARY KEY (player_id, game_id)
    )
    ''')
    
    # Pitching stats (daily)
    c.execute('''
    CREATE TABLE IF NOT EXISTS pitcher_daily (
        player_id INTEGER,
        player_name TEXT,
        team_id INTEGER,
        game_id TEXT,
        date TEXT,
        ip REAL,
        h INTEGER,
        r INTEGER,
        er INTEGER,
        bb INTEGER,
        k INTEGER,
        era REAL,
        whip REAL,
        ingested_at TEXT,
        PRIMARY KEY (player_id, game_id)
    )
    ''')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")

def store_games(games):
    """Store games in database"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    now = datetime.now().isoformat()
    
    for game in games:
        try:
            game_id = game['gamePk']
            date = game['gameDateTime'].split('T')[0]
            away_team = game['teams']['away']['team']['name']
            home_team = game['teams']['home']['team']['name']
            away_id = game['teams']['away']['team']['id']
            home_id = game['teams']['home']['team']['id']
            status = game['status']['abstractGameState']
            start_time = game['gameDateTime']
            venue = game.get('venue', {}).get('name', 'Unknown')
            
            away_score = game['teams']['away'].get('score', 0)
            home_score = game['teams']['home'].get('score', 0)
            inning = game.get('liveData', {}).get('linescore', {}).get('currentInning', 0)
            
            c.execute('''
            INSERT OR REPLACE INTO games 
            (game_id, date, away_team, home_team, away_id, home_id, status, 
             start_time, venue, away_score, home_score, inning, ingested_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (game_id, date, away_team, home_team, away_id, home_id, status,
                  start_time, venue, away_score, home_score, inning, now))
            
            logger.info(f"Stored game {game_id}: {away_team} @ {home_team}")
        except Exception as e:
            logger.error(f"Error storing game: {e}")
    
    conn.commit()
    conn.close()

def main():
    logger.info("=" * 60)
    logger.info("MLB Daily Ingest Started")
    logger.info("=" * 60)
    
    init_db()
    
    # Get today's games
    games = get_today_games()
    if not games:
        logger.warning("No games found for today")
        return
    
    store_games(games)
    
    # Save raw JSON for backup
    today = datetime.now().strftime("%Y-%m-%d")
    json_file = DATA_DIR / f"games_{today}.json"
    with open(json_file, 'w') as f:
        json.dump(games, f, indent=2)
    logger.info(f"Saved raw JSON: {json_file}")
    
    logger.info("=" * 60)
    logger.info("MLB Ingest Complete")
    logger.info("=" * 60)

if __name__ == "__main__":
    main()
