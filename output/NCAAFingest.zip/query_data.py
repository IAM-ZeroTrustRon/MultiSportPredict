#!/usr/bin/env python3
"""
Query ingested data for model input
Usage: python query_data.py --sport [mlb|ncaaf] --date [YYYY-MM-DD] --export [json|csv]
"""

import sqlite3
import json
import csv
import argparse
from datetime import datetime
from pathlib import Path

def query_mlb_games(date=None):
    """Query MLB games for a date"""
    db = Path("data/mlb/mlb.db")
    if not db.exists():
        print("MLB database not found. Run mlb_ingest.py first.")
        return []
    
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    if date:
        c.execute("SELECT * FROM games WHERE date = ? ORDER BY start_time", (date,))
    else:
        c.execute("SELECT * FROM games ORDER BY date DESC, start_time")
    
    games = [dict(row) for row in c.fetchall()]
    conn.close()
    return games

def query_ncaaf_games(date=None):
    """Query NCAAF games for a date"""
    db = Path("data/ncaaf/ncaaf.db")
    if not db.exists():
        print("NCAAF database not found. Run ncaaf_ingest.py first.")
        return []
    
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    if date:
        c.execute("""
            SELECT g.*, b.spread, b.over_under, b.public_pct_away, b.public_pct_home
            FROM games g
            LEFT JOIN betting_lines b ON g.game_id = b.game_id
            WHERE g.date = ?
            ORDER BY g.start_time
        """, (date,))
    else:
        c.execute("""
            SELECT g.*, b.spread, b.over_under, b.public_pct_away, b.public_pct_home
            FROM games g
            LEFT JOIN betting_lines b ON g.game_id = b.game_id
            ORDER BY g.date DESC, g.start_time
        """)
    
    games = [dict(row) for row in c.fetchall()]
    conn.close()
    return games

def export_json(data, filepath):
    """Export to JSON"""
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2, default=str)
    print(f"Exported to {filepath}")

def export_csv(data, filepath):
    """Export to CSV"""
    if not data:
        print("No data to export")
        return
    
    keys = data[0].keys()
    with open(filepath, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)
    print(f"Exported to {filepath}")

def main():
    parser = argparse.ArgumentParser(description="Query ingested sports data")
    parser.add_argument("--sport", choices=["mlb", "ncaaf"], required=True)
    parser.add_argument("--date", type=str, help="Query date (YYYY-MM-DD)")
    parser.add_argument("--export", choices=["json", "csv"], help="Export format")
    parser.add_argument("--output", type=str, help="Output file path")
    parser.add_argument("--limit", type=int, default=50, help="Limit results")
    
    args = parser.parse_args()
    
    # Query data
    if args.sport == "mlb":
        data = query_mlb_games(args.date)
    else:
        data = query_ncaaf_games(args.date)
    
    if not data:
        print(f"No {args.sport.upper()} data found for {args.date or 'any date'}")
        return
    
    # Limit results
    data = data[:args.limit]
    
    # Display summary
    print(f"\n{args.sport.upper()} Games ({len(data)} found)")
    print("=" * 80)
    
    if args.sport == "mlb":
        for game in data:
            print(f"{game['date']} | {game['away_team']:20} @ {game['home_team']:20} | "
                  f"{game['away_score']}-{game['home_score']} | {game['status']}")
    else:
        for game in data:
            spread = game['spread'] if game['spread'] else "N/A"
            ou = game['over_under'] if game['over_under'] else "N/A"
            print(f"{game['date']} | {game['away_team']:20} @ {game['home_team']:20} | "
                  f"Spread: {spread:6} | O/U: {ou:6}")
    
    # Export if requested
    if args.export:
        output_file = args.output or f"{args.sport}_{args.date or 'all'}.{args.export}"
        if args.export == "json":
            export_json(data, output_file)
        else:
            export_csv(data, output_file)
    
    print()

if __name__ == "__main__":
    main()
